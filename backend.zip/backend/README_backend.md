# Backend (FastAPI + Celery) — VBoxVGA Fix

## Подготовка
1) Установи/запусти Redis на `localhost:6379` (или укажи REDIS_URL).
2) Установка зависимостей:
```
cd backend
python -m venv .venv
.\.venv\Scriptsctivate
pip install -r requirements.txt
```

## Запуск
Окно 1 — Celery worker (Windows дружелюбный режим):
```
set REDIS_URL=redis://localhost:6379/0
celery -A app.celery_app.celery_app worker -l info -Q default -P solo -c 1
```
Окно 2 — API:
```
set REDIS_URL=redis://localhost:6379/0
uvicorn app.main:app --reload --port 8000
```

## Что менялось
- При клонировании принудительно выставляем `--graphicscontroller vboxvga` и VRAM, плюс диск первым в загрузке. Это устраняет запуск клонов в debug console.
- Логи стримятся через Redis pub/sub по каналу `logs:{job_id}`.
