# гарантируем, что при "from app.celery_app import celery_app"
# импортнётся именно объект Celery, а не подмодуль
from .celery_app import celery_app

__all__ = ["celery_app"]
