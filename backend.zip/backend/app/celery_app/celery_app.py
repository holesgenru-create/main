import os
from celery import Celery

REDIS_URL = os.getenv("REDIS_URL", "redis://localhost:6379/0")

# Единый Celery-инстанс на всё приложение
celery_app = Celery(
    "unikit",
    broker=REDIS_URL,
    backend=REDIS_URL,
    include=["app.tasks"],  # чтобы Celery видел задачи
)

# Базовая конфигурация очереди
celery_app.conf.task_default_queue = "default"
celery_app.autodiscover_tasks(["app"])
