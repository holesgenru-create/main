@echo off
setlocal
set REDIS_URL=redis://localhost:6379/0
.\.venv\Scripts\python -m uvicorn app.main:app --reload --port 8000
