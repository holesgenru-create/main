@echo off
setlocal
set REDIS_URL=redis://localhost:6379/0
.\.venv\Scripts\python -m celery -A app.celery_app.celery_app worker -l info -Q default -P solo -c 1
